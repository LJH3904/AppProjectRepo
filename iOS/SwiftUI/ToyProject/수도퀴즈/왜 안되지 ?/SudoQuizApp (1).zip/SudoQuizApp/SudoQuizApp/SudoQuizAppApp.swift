//
//  SudoQuizAppApp.swift
//  SudoQuizApp
//
//  Created by 신희권 on 2023/06/21.
//

import SwiftUI

@main
struct SudoQuizAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
